import uuid
import logging
from rest_framework import generics, permissions, status
from django.conf import settings
from django.utils import timezone
from django.db import transaction
from core.utils import success_response, error_response
from .models import PointAccount, PaymentHistory, PaymentStatus
from .serializers import (
    PointAccountSerializer,
    PaymentHistorySerializer,
    PointUseSerializer,
    PointChargeSerializer,
    DanalReadySerializer,
    DanalCallbackSerializer,
)
from .danal.client import DanalClient
from .tasks import sync_payment_to_mysql

logger = logging.getLogger(__name__)


class BalanceView(generics.GenericAPIView):
    """
    GET /api/v1/payment/balance/ — 포인트 잔액 조회 (인증 필요)
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        point_account, _ = PointAccount.objects.get_or_create(member=request.user)
        serializer = PointAccountSerializer(point_account)
        return success_response(serializer.data)


class PaymentHistoryListView(generics.GenericAPIView):
    """
    GET /api/v1/payment/history/ — 결제 내역 조회 (인증 필요)
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        queryset = PaymentHistory.objects.filter(
            member=request.user,
            is_deleted=False
        ).order_by('-created_at')

        # 필터: 성공 여부
        is_success = request.query_params.get('is_success')
        if is_success is not None:
            queryset = queryset.filter(is_success=(is_success.lower() == 'true'))

        # 페이지네이션
        page = int(request.query_params.get('page', 1))
        limit = int(request.query_params.get('limit', 20))
        total = queryset.count()
        offset = (page - 1) * limit
        histories = queryset[offset:offset + limit]

        serializer = PaymentHistorySerializer(histories, many=True)
        return success_response(
            serializer.data,
            meta={'page': page, 'total': total, 'limit': limit}
        )


class PointUseView(generics.GenericAPIView):
    """
    POST /api/v1/payment/use/ — 포인트 차감 (인증 필요)
    Request body: {"amount": 1000}
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = PointUseSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']

        with transaction.atomic():
            point_account, _ = PointAccount.objects.select_for_update().get_or_create(
                member=request.user
            )

            if point_account.balance < amount:
                return error_response(
                    'PAY_001',
                    f'포인트가 부족합니다. (잔액: {point_account.balance}, 요청: {amount})',
                    http_status=status.HTTP_400_BAD_REQUEST
                )

            # 포인트 차감
            point_account.total_used += amount
            point_account.last_used_at = timezone.now()
            point_account.save(update_fields=['total_used', 'last_used_at'])

        return success_response({
            'message': f'{amount} 포인트가 차감되었습니다.',
            'used_amount': amount,
            'remaining_balance': point_account.balance,
        })


class PointChargeView(generics.GenericAPIView):
    """
    POST /api/v1/payment/charge/ — 포인트 충전 요청 (인증 필요)
    다날 결제를 통한 포인트 충전 요청을 생성합니다.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = PointChargeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        pay_method = serializer.validated_data['pay_method']

        # 주문 ID 생성 (UUID 기반)
        order_id = f'DONGTA-{uuid.uuid4().hex[:16].upper()}'

        # 결제 내역 사전 생성 (대기 상태)
        payment = PaymentHistory.objects.create(
            member=request.user,
            amount=amount,
            point_amount=amount,  # 1원 = 1포인트
            pay_method=pay_method,
            status=PaymentStatus.PENDING,
            danal_order_id=order_id,
        )

        # 다날 결제 URL 구성
        danal_merchant_id = getattr(settings, 'DANAL_MERCHANT_ID', '')
        return_url = getattr(settings, 'DANAL_RETURN_URL', '')

        return success_response({
            'order_id': order_id,
            'amount': amount,
            'pay_method': pay_method,
            'payment_id': payment.id,
            'danal_merchant_id': danal_merchant_id,
            'return_url': return_url,
            'message': '결제 준비가 완료되었습니다. 다날 결제 창을 통해 결제를 진행하세요.',
        }, http_status=status.HTTP_201_CREATED)


class DanalReadyView(generics.GenericAPIView):
    """
    POST /api/v1/payment/danal/ready/ — 다날 결제 준비 (인증 필요)
    다날 PG 결제 세션을 초기화하고 결제 URL(STARTURL)을 반환합니다.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = DanalReadySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        pay_method = serializer.validated_data['pay_method']

        order_id = f'DONGTA-{uuid.uuid4().hex[:16].upper()}'

        # 1. 결제 내역 사전 생성 (PENDING)
        payment = PaymentHistory.objects.create(
            member=request.user,
            amount=amount,
            point_amount=amount,
            pay_method=pay_method,
            status=PaymentStatus.PENDING,
            danal_order_id=order_id,
        )

        # 2. 다날 API 호출 (READY)
        client = DanalClient()
        response = client.ready(
            order_id=order_id,
            amount=amount,
            item_name=f"동타포인트 {amount}P 충전",
            user_id=request.user.username,
            return_url=settings.DANAL_RETURN_URL,
            cancel_url=settings.DANAL_RETURN_URL
        )

        if response.is_success:
            payment.tid = response.get('TID')
            payment.save(update_fields=['tid'])

            return success_response({
                'order_id': order_id,
                'payment_id': payment.id,
                'tid': payment.tid,
                'amount': amount,
                'start_url': response.get('STARTURL'),
                'message': '결제 준비가 완료되었습니다. 다날 결제 창으로 이동하세요.',
            }, http_status=status.HTTP_201_CREATED)
        else:
            payment.status = PaymentStatus.REJECTED
            payment.result_code = response.return_code
            payment.result_message = response.return_msg
            payment.save(update_fields=['status', 'result_code', 'result_message'])
            
            return error_response(
                'PAY_002', 
                f'다날 서버 통신 실패: {response.return_msg}',
                http_status=status.HTTP_400_BAD_REQUEST
            )


class DanalCallbackView(generics.GenericAPIView):
    """
    POST /api/v1/payment/danal/callback/ — 다날 결제 결과 수신 및 승인 (서버-서버)
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        tid = request.data.get('TID')
        order_id = request.data.get('ORDERID')
        
        if not tid or not order_id:
            return error_response('PAY_003', '유효하지 않은 결제 결과입니다.')

        try:
            payment = PaymentHistory.objects.get(danal_order_id=order_id, tid=tid)
        except PaymentHistory.DoesNotExist:
            return error_response('PAY_002', '해당 주문을 찾을 수 없습니다.')

        if payment.status == PaymentStatus.APPROVED:
            return success_response({'message': '이미 승인된 결제입니다.', 'order_id': order_id})

        client = DanalClient()
        response = client.approve(tid=tid)

        is_success = response.is_success
        
        with transaction.atomic():
            payment.result_code = response.return_code
            payment.result_message = response.return_msg
            payment.is_success = is_success
            payment.status = PaymentStatus.APPROVED if is_success else PaymentStatus.REJECTED
            payment.danal_response = response.raw
            
            if is_success:
                payment.confirmed_at = timezone.now()
            
            payment.save(update_fields=[
                'result_code', 'result_message', 'is_success', 
                'status', 'confirmed_at', 'danal_response'
            ])

            if is_success:
                point_account, _ = PointAccount.objects.select_for_update().get_or_create(
                    member=payment.member
                )
                point_account.total_charged += payment.point_amount
                point_account.last_charged_at = timezone.now()
                point_account.save(update_fields=['total_charged', 'last_charged_at'])

        if is_success:
            sync_payment_to_mysql.delay(payment.id)
            return success_response({
                'message': f'{payment.point_amount} 포인트가 충전되었습니다.',
                'order_id': order_id,
                'point_amount': payment.point_amount,
            })
        else:
            return error_response(
                'PAY_002', 
                f'결제 승인 실패: {response.return_msg}',
                http_status=status.HTTP_400_BAD_REQUEST
            )


class DanalCancelView(generics.GenericAPIView):
    """
    POST /api/v1/payment/danal/cancel/ — 다날 결제 취소 (인증 필요)
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        payment_id = request.data.get('payment_id')
        reason = request.data.get('reason', '사용자 요청 취소')

        try:
            payment = PaymentHistory.objects.get(
                id=payment_id, 
                member=request.user, 
                status=PaymentStatus.APPROVED
            )
        except PaymentHistory.DoesNotExist:
            return error_response('PAY_002', '취소 가능한 결제 내역을 찾을 수 없습니다.')

        client = DanalClient()
        response = client.cancel(tid=payment.tid, amount=payment.amount, reason=reason)

        if response.is_success:
            with transaction.atomic():
                point_account = PointAccount.objects.select_for_update().get(member=request.user)
                
                if point_account.balance < payment.point_amount:
                    return error_response('PAY_001', '이미 사용된 포인트는 취소할 수 없습니다.')

                point_account.total_charged -= payment.point_amount
                point_account.save(update_fields=['total_charged'])

                payment.status = PaymentStatus.CANCELLED
                payment.result_message = f"취소완료: {reason}"
                payment.save(update_fields=['status', 'result_message'])
            
            return success_response({'message': '결제가 취소되었습니다.'})
        else:
            return error_response('PAY_004', f'취소 실패: {response.return_msg}')
